import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle2, Phone } from "lucide-react";
import { motion } from "framer-motion";
import teamImage from "@/assets/team-collab.jpg";
import workspaceImage from "@/assets/workspace.jpg";

const trustItems = ["Für Handwerksbetriebe", "Ohne Technikstress", "Direkter Ansprechpartner"];

const HeroSection = () => {
  return (
    <section id="hero" className="relative overflow-hidden pt-24 sm:pt-28 pb-10 sm:pb-12">
      <div className="absolute top-20 right-[-140px] h-[320px] w-[320px] rounded-full bg-primary/5 blur-3xl" />
      <div className="absolute bottom-0 left-[-100px] h-[250px] w-[250px] rounded-full bg-accent/10 blur-3xl" />

      <div className="container mx-auto relative">
        <div className="grid items-end gap-8 lg:grid-cols-12 lg:gap-10">
          <motion.div
            className="lg:col-span-7"
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: [0.25, 0.46, 0.45, 0.94] }}
          >
            <div className="inline-flex items-center rounded-full border border-border px-3 py-1.5 mb-5 sm:mb-6">
              <span className="text-xs sm:text-sm font-body tracking-[0.16em] uppercase text-muted-foreground">
                Webseiten für Handwerksbetriebe
              </span>
            </div>

            <h1 className="text-[2.15rem] leading-[1.02] sm:text-5xl lg:text-[4rem] xl:text-[4.6rem] tracking-tight mb-4 sm:mb-6">
              Mehr passende Anfragen.
              <br />
              <span className="italic text-primary">Klare Webseite für Ihren Betrieb.</span>
            </h1>

            <p className="text-lg sm:text-xl lg:text-[1.35rem] text-muted-foreground font-body max-w-xl leading-relaxed mb-6 sm:mb-8">
              Wir bauen in kurzer Zeit eine mobile Webseite, die Vertrauen schafft, Leistungen klar zeigt und neue Kundenkontakte planbar macht.
            </p>

            <ul className="grid gap-2 text-base sm:text-lg font-body text-foreground/85 mb-6 sm:mb-8">
              {trustItems.map((item) => (
                <li key={item} className="inline-flex items-center gap-2.5">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  {item}
                </li>
              ))}
            </ul>

            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <Button asChild variant="hero" size="xl" className="w-full sm:w-auto">
                <a href="#qualifizierung">
                  60-Sekunden-Check starten <ArrowRight className="w-5 h-5" />
                </a>
              </Button>
              <Button asChild variant="hero-outline" size="xl" className="w-full sm:w-auto">
                <a href="tel:+49800123456">
                  <Phone className="w-4 h-4" /> 0800 123 456
                </a>
              </Button>
            </div>
            <p className="text-sm sm:text-base text-muted-foreground font-body mt-3">
              Kostenlos · Unverbindlich · Auf Handwerk ausgerichtet
            </p>
          </motion.div>

          <motion.div
            className="lg:col-span-5"
            initial={{ opacity: 0, x: 28 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.65, delay: 0.15, ease: [0.25, 0.46, 0.45, 0.94] }}
          >
            <div className="relative mx-auto max-w-[520px]">
              <img
                src={teamImage}
                alt="Handwerker-Webseite auf verschiedenen Geräten"
                className="w-full rounded-2xl shadow-elevated object-cover aspect-[4/3]"
              />
              <img
                src={workspaceImage}
                alt="Google-Ergebnisse für Handwerksbetrieb"
                className="absolute -bottom-5 left-3 sm:left-5 w-[68%] rounded-xl shadow-elevated object-cover aspect-video border-4 border-background"
              />

              <div className="absolute top-3 right-3 sm:right-4 rounded-xl bg-secondary text-secondary-foreground p-3 sm:p-4 shadow-elevated">
                <p className="font-display text-2xl sm:text-3xl leading-none">+67%</p>
                <p className="text-xs sm:text-sm font-body text-secondary-foreground/65 mt-1">mehr qualifizierte Anfragen</p>
              </div>
            </div>
          </motion.div>
        </div>

        <motion.div
          className="mt-10 sm:mt-12 grid grid-cols-1 gap-3 sm:grid-cols-3"
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.45 }}
        >
          <div className="rounded-xl border border-border bg-card/70 px-4 py-3">
            <p className="font-display text-2xl sm:text-3xl text-foreground leading-none">380+</p>
            <p className="text-sm text-muted-foreground font-body mt-1">Handwerker-Webseiten</p>
          </div>
          <div className="rounded-xl border border-border bg-card/70 px-4 py-3">
            <p className="font-display text-2xl sm:text-3xl text-foreground leading-none">4.9★</p>
            <p className="text-sm text-muted-foreground font-body mt-1">Google-Bewertung</p>
          </div>
          <div className="rounded-xl border border-border bg-card/70 px-4 py-3">
            <p className="font-display text-2xl sm:text-3xl text-foreground leading-none">14 Tage</p>
            <p className="text-sm text-muted-foreground font-body mt-1">Durchschnitt bis live</p>
          </div>
        </motion.div>

        <div className="mt-6 sm:mt-8 rounded-xl border border-border bg-background/75 px-4 py-3 sm:px-5 sm:py-4">
          <p className="text-sm sm:text-base font-body text-muted-foreground leading-relaxed">
            Für Handwerksbetriebe aus Deutschland, Österreich und der Schweiz, die online gefunden werden und wiederkehrend passende Anfragen erhalten wollen.
          </p>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
